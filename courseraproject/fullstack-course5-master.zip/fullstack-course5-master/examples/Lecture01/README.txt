There is no code corresponding to this lecture. Please see the video and possible slides.
