(function () {
'use strict';

angular.module('myFirstApp', [])

.controller('MyFirstController', function () {

});

})();
