All application code copied from Lecture22.
